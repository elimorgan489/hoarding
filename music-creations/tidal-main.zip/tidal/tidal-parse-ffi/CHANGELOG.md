# Changelog for tidal-parse-ffi

## Unreleased

### Added

- FFI bindings for `tidal-parse`.
- `cabal.project` integration.

### Changed

- Updated dependencies and metadata.
- Performance improvements.

### Fixed

- Stability and bug fixes.

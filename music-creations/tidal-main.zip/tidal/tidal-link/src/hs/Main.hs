module Main where

import Sound.Tidal.Link (hello)

main :: IO ()
main = hello

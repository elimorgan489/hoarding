# tidal-link

Ableton Link integration for Tidal

Requires fixes to GHC on Windows (see https://gitlab.haskell.org/ghc/ghc/-/issues/20918)
which are available from GHC 9.2.4.

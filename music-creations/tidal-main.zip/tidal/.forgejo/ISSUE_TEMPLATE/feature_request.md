---
name: Feature request
about: Suggest an idea for TidalCycles

---

**Describe the function/feature you'd like**
A description of what you want to happen, along with "pseudocode" examples as appropriate. All ideas are very welcome, especially 'stupid' ones.

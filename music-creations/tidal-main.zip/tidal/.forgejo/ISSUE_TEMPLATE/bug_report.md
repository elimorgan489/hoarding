---
name: Bug report
about: Create a report to help TidalCycles improve

---

**Describe the bug**
Please describe the bug, along with the code example, and any errors you get. Please also give the version of tidal you're using, which you can get by running `tidal_version` in a tidal session.

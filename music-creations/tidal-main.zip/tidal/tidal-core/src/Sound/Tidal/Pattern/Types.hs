module Sound.Tidal.Pattern.Types where

patternTimeID :: String
patternTimeID = "_t_pattern"

# tidal-parse
The parser of tidal formerly known as MiniTidal

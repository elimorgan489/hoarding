No longer current -- see supercollider.tidal

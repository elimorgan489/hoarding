Various scripts for sending OSC pulses over a network.

For step-by-step instructions, please refer to
http://tidal.lurk.org/getting_started.html.

# Alternative Install Script

The following currently assumes a Debian, or Debian-derived Linux
distribution such as Ubuntu or Mint, although it should be quite easy
to adapt to another distribution.

Unless otherwise specified, you will need to run the commands below in
a terminal window.

An installation script now exists, which should mostly work under
recent debian based distributions. It comes with no warranty,
though. It's available here, click 'raw' to download it:

  <https://github.com/yaxu/Tidal/blob/master/doc/install-linux.sh>

Once you have run that script, log out and then back in again (to ensure you have the right group settings), and if all is well, you should be good to go.

Alternatively, you can follow the step-by-step instructions below.

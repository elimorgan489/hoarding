Please refer to http://tidal.lurk.org/getting_started.html for installation
instructions on Windows.

Documentation has now moved to the Tidal website:
  http://tidal.lurk.org/

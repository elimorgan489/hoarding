# Revision history for ui

## 1.0.0 -- 2024-12-26

* First version. Released on an unsuspecting world.

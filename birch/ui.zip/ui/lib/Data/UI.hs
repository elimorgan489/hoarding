{-|
Module      : Data.UI
Description : Minimalistic console UI (getLine), arrow key support
               (edit, browse cmd history).
Copyright   : (c) dr. Jonas Birch, 2024
License     : MIT
Maintainer  : dr. Jonas Birch <mnt@doctorbirch.com>
Stability   : stable
Portability : POSIX

The __UI library__ provides a more modern /getLine/ style function for making console based CLIs (command line interfaces). The library provides editing capabilities through the use of arrow keys, as well as browsing through the command history.

It is very minimalistic, does only export two functions and doesn't require its own monad (only IO).
-}
module Data.UI (
    -- * Data types
    --
    Term(..), TermRes(..),
    -- * Functions
    --
    init, input
) where

import Prelude hiding (init, Left, Right, log)
import GHC.IO.Handle (
    hIsTerminalDevice, hSetBuffering, hSetEcho,
    hGetBuf, hFlush
 )
import Control.Monad (unless)
import Data.Char (chr)
import Data.Word (Word16)
import Foreign.Marshal.Alloc (allocaBytes)
import GHC.IO.Handle.Types (BufferMode(..))
import GHC.IO.Handle.FD (stdin,stdout)
import GHC.Storable (writeIntOffPtr, readIntOffPtr)
import Text.Printf (printf)

import Data.Util (
    Vector,
    betw, filter3, inject, vnew, (§), (§:)
 )

maxcols :: Int
maxcols = 80

a :: String -> IO ()
a = putstr . printf "\x1b[%s"
a' :: String -> String
a' = printf "\x1b[%s"

erasel,scrmode :: IO ()
erasel  = a "2K\r"
scrmode = a $ "=3h" <> a' "=7hl"

col  :: Int -> IO ()
col  n = a (show n <> "G")
col' :: Int -> String
col' n = a' (show n <> "G")
-- mup  :: Int -> IO ()
-- mup n = if n == 0 then
--     return ()
--  else
--     a (show (n - 1) <> "A")

-- | Line is the datatype of the returned text string when
--  the user presses enter. This type can easily be changed
--  from the default (String) to Text or anything else. Change
--  it in the type alias and it will be used everywhere.
type Line = String
type Key  = Word16

-- | Term is the internal state of the library.
data Term = Term
 { initialized  :: Bool
 , log          :: Vector Line
 , logpos       :: Int
 , loglen       :: Int
 , buf          :: Line
 , len          :: Int
 , pos          :: Int
 , prompt       :: Line
 }
 deriving stock Show

mkterm :: Line -> Term
mkterm pr =
    Term False (vnew 2 "") 0 2 "" 0 (length pr + 1) pr

-- | TermRes is the result of the input. Returned whenever the user presses a key.
data TermRes =
    TKey Key        -- ^ Returns the numeric value on each key press (except enter).
    | TLine Line    -- ^ Returns the line of data when user presses enter.
--    | THelp Line
instance Show TermRes where
    show (TKey k)  = printf "0x%.04hx" k
    show (TLine s) = s
--    show (THelp s) = s

data Arrow =
    Up
    | Right
    | Down
    | Left
    deriving stock Show

toarrow :: Key -> Arrow
toarrow 0x415b = Up
toarrow 0x435b = Right
toarrow 0x425b = Down
toarrow 0x445b = Left
toarrow _      = error "Non arrow value passed to toarrow."

-- | __init__ /initial_prompt/
--
-- Initializes the terminal. Returns a handle which you pass
-- on to the __input__ function.
init :: Line -> IO Term
init pr = do
    let
        term = mkterm pr
    hastty <- hIsTerminalDevice stdin
    unless hastty $
        error "No valid tty"
    _ <- hSetBuffering stdin NoBuffering
    _ <- hSetEcho stdin False
    _ <- scrmode
    _ <- col 0
    _ <- erasel
    let
        term' = term { initialized = True }
    return term'

putstr :: String -> IO ()
putstr s = do
    _ <- putStr s
    hFlush stdout

-- split :: Int -> String -> String
-- split = split' []

-- split' :: String -> Int -> String -> String
-- split' acc _ [] = acc
-- split' [] n xs
--  | length xs < n = xs
-- split' !acc n xs
--  | length xs < n = acc <> ('\r':xs)
-- split' [] n xs =
--     split' (take n xs) n (drop n xs)
-- split' !acc n xs =
--     split' (acc <> "\r" <> take n xs) n (drop n xs)

-- | __input__ /handle/
--
-- Reads one character from the keyboard. You give it the handle
-- from the last function call. It returns the string when pressed
-- enter and returns the key code otherwise.
--
-- __Example:__
-- > import qualified Data.UI (init, input)
-- > import Data.UI (TermRes(..))
-- > 
-- > example :: IO ()
-- > example = do
-- >     t <- Data.UI.init "prompt> "
-- >     go t
-- >     where
-- >      go t' = do
-- >         (res,newstate) <- Data.UI.input t'
-- >         case res of
-- >             TLine x  -> do
-- >                          _ <- putStrLn $ "\nResult: '" <> x <> "'"
-- >                          go newstate
-- >             _        -> go newstate
input :: Term -> IO (TermRes,Term)
input t = do
    _ <- erasel
    _ <- putstr $ t.prompt <> t.buf -- (split maxcols t.buf)
    _ <- col t.pos
    c <- allocaBytes 4 $ \p -> do
        _ <- writeIntOffPtr p 0 0
        n <- hGetBuf stdin p 1
        if n /= 1 then
            return 0
        else do
            c <- readIntOffPtr p 0
            let
                c' = fromIntegral c :: Key
            case c' of
                0x1b -> do
                    _ <- writeIntOffPtr p 0 0
                    n' <- hGetBuf stdin p 2
                    if n' /= 2 then
                        return 0
                    else do
                        c_ <- readIntOffPtr p 0
                        let
                            c'' = fromIntegral c_ :: Key
                        return c''
                _       -> return c'
    let
        (mr,t',ansi) = case c of
            n | betw 0x20 0x7e n'   -> addchar t $ chr n'
             where
                n' = fromIntegral n :: Int
            0x7f                    -> delchar t
            0x0a                    -> execute t
            n | n `elem` arrs       -> arr t $ toarrow n
            _                       -> (Nothing,t,"")
        ret = case mr of
            Just x  -> x
            Nothing -> TKey c
        arrs = [0x415b, 0x435b, 0x425b, 0x445b]
    _ <- putstr ansi
    return (ret,t')
 where
    addchar :: Term -> Char -> (Maybe TermRes,Term,String)
    delchar,execute :: Term -> (Maybe TermRes,Term,String)
    arr    :: Term -> Arrow -> (Maybe TermRes,Term,String)
    addchar trm =
        case trm.len + length trm.prompt of
            n | n > maxcols -> const (Nothing,trm,"\x07")
            _               ->
                  if rightmost trm then naiveaddchar trm else caddchar trm
    delchar trm = if rightmost trm then naivedelchar trm else cdelchar trm

    rightmost :: Term -> Bool
    rightmost trm = let
        pos' = trm.len + length trm.prompt + 1
     in
        trm.pos == pos'

    execute trm = let
        trm' = if trm.len == 0 then trm else trm {
            buf = "",
            len = 0,
            pos = length trm.prompt + 1,
            loglen = trm.loglen + 1,
            logpos = 0,
            log = trm.buf§:trm.log
        }
     in
        (Just $ TLine trm.buf,trm',col' trm'.pos)

    arr trm Left = let
        trm' = if trm.pos == (length trm.prompt + 1) then trm else trm {
            pos = trm.pos - 1
        }
     in
        (Nothing,trm',col' trm'.pos)
    arr trm Right = let
        trm' = if rightmost trm then trm else trm {
            pos = trm.pos + 1
        }
     in
        (Nothing,trm',col' trm'.pos)
    arr trm Up
     | trm.logpos == (trm.loglen - 1) = (Nothing,trm,"")
    arr trm Up = let
        trm' = trm {
            logpos = newpos,
            buf = newbuf,
            len = length newbuf,
            pos = (length trm.prompt + 1) + newlen
        }
     in
        (Nothing,trm',col' trm'.pos)
     where
        newpos = trm.logpos + 1
        newbuf = trm.log § newpos
        newlen = length newbuf
    arr trm Down
     | trm.logpos == 0 = (Nothing,trm,"")
    arr trm Down = let
        trm' = trm {
            logpos = newpos,
            buf = newbuf,
            len = length newbuf,
            pos = (length trm.prompt + 1) + newlen
        }
     in
        (Nothing,trm',col' trm'.pos)
     where
        newpos = trm.logpos - 1
        newbuf = trm.log § newpos
        newlen = length newbuf

    naiveaddchar :: Term -> Char -> (Maybe TermRes,Term,String)
    naiveaddchar trm ch = let
        trm' = trm {
            buf = (reverse . (ch:) . reverse) trm.buf,
            len = trm.len + 1,
            pos = trm.pos + 1
        }
     in
        (Nothing,trm',col' trm'.pos)
    
    caddchar :: Term -> Char -> (Maybe TermRes,Term,String)
    caddchar trm ch = let
        trm' = trm {
            len = trm.len + 1,
            pos = trm.pos + 1,
            buf = inject ch (trm.pos - length trm.prompt - 1) trm.buf
        }
     in
        (Nothing,trm',col' trm'.pos)
    
    naivedelchar :: Term -> (Maybe TermRes,Term,String)
    naivedelchar trm = let
        trm' = if trm.pos == length trm.prompt + 1 then trm else trm {
            buf = take (trm.len - 1) trm.buf,
            len = trm.len - 1,
            pos = trm.pos - 1
        }
     in
        (Nothing,trm',col' trm'.pos)

-- sh int status
    
    cdelchar :: Term -> (Maybe TermRes,Term,String)
    cdelchar trm = let
        trm' = if trm.pos == length trm.prompt + 1 then trm else trm {
            len = trm.len - 1,
            pos = trm.pos - 1,
            buf = filter3 f trm.buf
        }
        f :: a -> Int -> [a] -> Bool
        f _ n _ = n /= (trm.pos - length trm.prompt - 2)
     in
        (Nothing,trm',col' trm'.pos)


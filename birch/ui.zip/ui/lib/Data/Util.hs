module Data.Util (
    V.Vector,
    betw, filter3, inject, lowercase, nextn, next5, replace,
    splitat, vnew, (><), (§), (§=), (§:)
) where

import Data.Char (toLower)
import qualified Data.Vector as V
import Data.Vector (Vector)

betw :: Int -> Int -> Int -> Bool
betw s e n = s <= n && n <= e

filter3 :: (Num n, Eq n, Eq a) => (a -> n -> [a] -> Bool) -> [a] -> [a]
filter3 fun ys = map3 fun ys ys [] 0
 where
    map3 :: (Num n, Eq n, Eq a) =>
        (a -> n -> [a] -> Bool) -> [a] -> [a] -> [a] -> n -> [a]
    map3 _ _ [] ta _ = reverse ta
    map3 f xs [a] !ta !n = if f a n xs then
        map3 f xs [] (a:ta) (n + 1)
        else map3 f xs [] ta (n + 1)
    map3 f xs (a:as) !ta !n = if f a n xs then
        map3 f xs as (a:ta) (n + 1)
        else map3 f xs as ta (n + 1)

inject :: Char -> Int -> String -> String
inject c p xs = let
    (left,right)    = splitat p xs
    ret             = left <> (c:right)
 in
    ret

lowercase :: String -> String
lowercase = fmap toLower

nextn :: Int -> Int -> Int
nextn n x
    | x `mod` n == 0 = x
nextn n x = nextn n (x + 1)

next5 :: Int -> Int
next5 = nextn 5

replace :: Char -> Char -> String -> String
replace from to xs = [if x==from then to else x | x <- xs]

splitat :: Int -> String -> (String,String)
splitat p xs = let
    len     = length xs
    nright  = len - p
    left    = take p xs
    right   = (reverse . (take nright) . reverse) xs
    ret     = (left,right)
 in
    ret

vnew :: Int -> a -> Vector a
vnew = V.replicate

vaccess :: Vector a -> Int -> a
vaccess v n
 | n <= len = (V.!) v n
 | otherwise = error "Vector out of bounds"
 where
    len = V.length v - 1

vcons :: a -> Vector a -> Vector a
vcons a v
 | n >= 2 = let
    olda = v § 0
    v' = V.ifilter f v
    f :: Int -> a -> Bool
    f i _ = i /= 0
    ret = V.cons olda $ V.cons a v'
 in
    ret
 where
    n = V.length v
vcons a v = V.cons a v

vset :: Vector a -> Int -> a -> Vector a
vset v n a
 | n <= len = V.unsafeUpdate_ v (V.singleton n) (V.singleton a)
 | otherwise = error "Vector out of bounds"
 where
    len = V.length v - 1

infixl 4 §
(§) :: Vector a -> Int -> a
(§) = vaccess

infixl 4 §=
(§=) :: (Vector a,Int) -> a -> Vector a
(§=) (v,n) = vset v n

infixl 4 §:
(§:) :: a -> Vector a -> Vector a
(§:) = vcons

infixl 4 ><
(><) :: a -> [a] -> [a]
(><) x = Prelude.reverse . (:) x . Prelude.reverse
module Main where

import qualified Data.UI (init, input)
import Data.UI (TermRes(..))

example :: IO ()
example = do
    t <- Data.UI.init "prompt> "
    go t
    where
     go t' = do
        (res,newstate) <- Data.UI.input t'
        case res of
            TLine x  -> do
                         _ <- putStrLn $ "\nResult: '" <> x <> "'"
                         go newstate
{-
            TKey n   -> do
                         _ <- putStrLn "\nKey: " <> show n
                         go newstate
-}
            _        -> go newstate

main :: IO ()
main = example
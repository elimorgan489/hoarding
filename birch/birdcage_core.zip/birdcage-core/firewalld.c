/* firewalld.c */
#include "firewalld.h"

void memorycopy(int8 *dst, int8 *src, int32 size) {
    int8 *d, *s;
    int32 n;

    for (d=dst, s=src, n=size; n; d++, s++, n--)
        *d = *s;
    
    return;
}

int16 stringlen(int8 *str) {
    int8 *p;
    int16 n;

    for (p = str, n=0; *p; p++, n++);

    return n;
}

dynamic *mkdynamic_(int16 entrysize, int8 *datatype) {
    dynamic *p;
    int32 size;

    size = sizeof(struct s_dynamic) + (entrysize*Blocksize);
    p = (dynamic *)malloc($i size);

    assert(p);
    zero($1 p, size);

    p->count = 0;
    p->capacity = Blocksize;
    p->entrysize = entrysize;
    memorycopy(p->type, datatype, min(stringlen(datatype), 15));

    return p;
}

void dynadd(dynamic *arr, void *entry) {
    int32 size, n, cap, idx;
    int8 *p;
   
    if (arr->count >= arr->capacity) {
        cap = arr->capacity + Blocksize;
        size = (arr->entrysize * cap);
        n = sizeof(struct s_dynamic) + size;
        arr = (dynamic *)realloc(arr, $i n);
        assert(arr);
        arr->capacity = cap;
    }

    idx = arr->count;
    p = arr->data + (arr->entrysize*idx);

    memorycopy(p, $1 entry, arr->entrysize);
    arr->count++;

    return;
}

void dynprint_(dynamic *arr, int8 *var) {
    assert(arr);

    printf(
        "Printing '%s'\n"
        "  datatype:  %s\n"
        "  capacity:  %d\n"
        "  count:     %d\n"
        "  entrysize: %d\n\n",
            var, arr->type, arr->capacity,
            arr->count, arr->entrysize
        );
        
        if (arr->count) {
            printhex(arr->data, min((arr->count*arr->entrysize), 32), 0);
            printf("\n");
        }

        return;
}

int main(int argc, char *argv[]) {
    int x;
    dynamic *arr;

    arr = mkdynamic(int);
    x=1; dynadd(arr, &x);
    x=2; dynadd(arr, &x);
    x=3; dynadd(arr, &x);
    x=4; dynadd(arr, &x);
    x=5; dynadd(arr, &x);
     x=1; dynadd(arr, &x);
    x=2; dynadd(arr, &x);
    x=3; dynadd(arr, &x);
    x=4; dynadd(arr, &x);
    x=5; dynadd(arr, &x);
     x=1; dynadd(arr, &x);
    x=2; dynadd(arr, &x);
    x=3; dynadd(arr, &x);
    x=4; dynadd(arr, &x);
    x=5; dynadd(arr, &x);
     x=1; dynadd(arr, &x);
    x=2; dynadd(arr, &x);
    x=3; dynadd(arr, &x);
    x=4; dynadd(arr, &x);
    x=5; dynadd(arr, &x);
     x=1; dynadd(arr, &x);
    x=2; dynadd(arr, &x);
    x=3; dynadd(arr, &x);
    x=4; dynadd(arr, &x);
    x=5; dynadd(arr, &x);
     x=1; dynadd(arr, &x);
    x=2; dynadd(arr, &x);
    x=3; dynadd(arr, &x);
    x=4; dynadd(arr, &x);
    x=5; dynadd(arr, &x);
     x=1; dynadd(arr, &x);
    x=2; dynadd(arr, &x);
    x=3; dynadd(arr, &x);
    x=4; dynadd(arr, &x);
    x=5; dynadd(arr, &x);
    dynprint(arr);
    free(arr);

    return 0;
}


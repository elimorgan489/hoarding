{-# language CPP #-}
#define Version "1.0"

{-# options_ghc -Wno-x-partial #-}
module Main (main) where
import Prelude
import Compiler (compile)
import System.Environment (getArgs)

version :: String
version = Version

usage :: IO ()
usage = putStrLn $ "Usage: rookery [--version] "
                  <> "<input.asm> -o <output>"

printver :: IO ()
printver = putStrLn $ "Rookery v"
                      <> version
                      <> " by @dr-Jonas-Birch"

main :: IO ()
-- main = L.testing
main = do
  argv <- getArgs
  let
    argc = length argv
    ret = if argc < 3 then
        if argc == 1 && head argv == "--version" then
          printver
        else usage
    else
      let
        inp = head argv
        dasho = argv !! 1
        out = argv !! 2
      in
        if dasho == "-o" then compile inp out
        else usage
  ret

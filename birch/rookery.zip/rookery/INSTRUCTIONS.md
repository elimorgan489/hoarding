# Instructions

1. Download and install ghc (Glasgow Haskell Compiler).
2. Download and install cabal (the Haskell package manager/build system).
3. Download and install GNU Make.
4. Run: make
5. Run the program by running "cabal run" or execute the rookery file directly.

Usage: rookery file.asm -o outputfile.bin

Then just load the executable into a 16-bit birdnest virtual machine.


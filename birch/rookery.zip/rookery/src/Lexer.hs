{-# language BangPatterns #-}
{-# LANGUAGE DerivingStrategies #-}
{-# language FlexibleInstances  #-}
{-# language GeneralizedNewtypeDeriving #-}
{-# language InstanceSigs  #-}
{-# language KindSignatures #-}
{-# LANGUAGE LambdaCase #-}
{-# language QuantifiedConstraints #-}
{-# language ScopedTypeVariables #-}
{-# language TypeApplications #-}
{-# OPTIONS_GHC -fno-warn-unused-binds #-}
module Lexer where
    -- Lexer(..), Token(..),
    -- lex, char, string, anychar, anystring, keyword,
    -- instruction, label, assembly, 
import Data.Word (Word8, Word16)
import Prelude hiding (Word, lex)
import Control.Applicative (Alternative(..))
import Control.Monad (guard)
import Data.Char (isDigit)

assembly :: Lexer Token
assembly = keyword <|> space <|> pointers <|> instruction
    <|> space <|> colon <|> comma <|> eol
    <|> int <|> register
    <|> eof <|> label

type Word = Word16

newtype Label = Label String
    deriving newtype (Show,Eq)

data Bitspace =
    Whole
    | Higher
    | Lower
    | Pointer
    deriving stock (Show,Eq)

data Reg =
    Ax Bitspace
    | Bx Bitspace
    | Cx Bitspace
    | Dx Bitspace
    | Sp
    | Ip
    deriving stock (Show,Eq)

data Inst =
    Ste
    | Stg
    | Sth
    | Stl
    | Cle
    | Clh
    | Cll
    | Clg
    | Mov
    | Nop
    | Hlt
    deriving stock (Show,Eq)

data Keyword =
    Entry
    | Bits
    deriving stock (Show,Eq)

data Token =
    Keyword' Keyword
    | Label' Label
    | Eol'
    | Int' Word
    | Colon'
    | Inst' Inst
    | Space'
    | Reg' Reg
    | Eof'
    | Void' Word8
    | Comma'
    | OpenBracket'
    | CloseBracket'
    deriving stock (Show,Eq)

space,colon,comma,eol,bopen,bclose :: Lexer Token
space  = fc ' ' Space'
colon  = fc ':' Colon'
comma  = fc ',' Comma'
eol    = fc '\n' Eol'
bopen  = fc '[' OpenBracket'
bclose = fc ']' CloseBracket'

int :: Lexer Token
int = do
    x <- stringuntil notseparator `suchthat` -- `unless` (== "") `suchthat`
        all (`elem` valid)
    return $ Int' $ atoi x
    where
        isnumber :: String -> Bool
        isnumber = all isDigit
        valid :: String
        valid = "0123456789"

dtoi :: Char -> Word
dtoi c
 | c == '0' = 0
 | c == '1' = 1
 | c == '2' = 2
 | c == '3' = 3
 | c == '4' = 4
 | c == '5' = 5
 | c == '6' = 6
 | c == '7' = 7
 | c == '8' = 8
 | c == '9' = 9
 | otherwise = error "Bad input"

atoi' :: String -> Word -> Word
atoi' [] !b = b
atoi' (x:xs) !b = atoi' xs (b*10 + dtoi x)

atoi :: String -> Word
atoi xs = atoi' xs 0

eof :: Lexer Token
eof = Lexer $ \case
    ""  -> Just (Eof',"")
    _   -> Nothing

-- fromchar
fc :: Char -> Token -> Lexer Token
fc c t = do
    _ <- char c
    return t

pointers :: Lexer Token
pointers = do
    _ <- bopen
    r <- string "ax" <|> string "bx" <|> string "cx" <|> string "dx"
    _ <- bclose
    return $ case r of
        "ax"    -> Reg' $ Ax Pointer
        "bx"    -> Reg' $ Bx Pointer
        "cx"    -> Reg' $ Cx Pointer
        "dx"    -> Reg' $ Dx Pointer
        _       -> error "Parse error"

register :: Lexer Token
register = str2in <$> registers
    where
        str2in :: String -> Token
        str2in k
         | k == "ax" = Reg' $ Ax Whole
         | k == "bx" = Reg' $ Bx Whole
         | k == "cx" = Reg' $ Cx Whole
         | k == "dx" = Reg' $ Dx Whole
         | k == "sp" = Reg' Sp
         | k == "ip" = Reg' Ip
         | k == "ah" = Reg' $ Ax Higher
         | k == "bh" = Reg' $ Bx Higher
         | k == "ch" = Reg' $ Cx Higher
         | k == "dh" = Reg' $ Dx Higher
         | k == "al" = Reg' $ Ax Lower
         | k == "bl" = Reg' $ Bx Lower
         | k == "cl" = Reg' $ Cx Lower
         | k == "dl" = Reg' $ Dx Lower

         | otherwise  = error "Illegal instruction"
        
        registers :: Lexer String
        registers = string "ip"
                     <|> string "sp"
                     <|> string "ax"
                     <|> string "bx"
                     <|> string "cx"
                     <|> string "dx"
                     <|> string "ah"
                     <|> string "bh"
                     <|> string "ch"
                     <|> string "dh"
                     <|> string "al"
                     <|> string "bl"
                     <|> string "cl"
                     <|> string "dl"

instruction :: Lexer Token
instruction = str2in <$> instructions
    where
        str2in :: String -> Token
        str2in k
         | k == "ste" = Inst' Ste
         | k == "mov" = Inst' Mov
         | k == "nop" = Inst' Nop
         | k == "hlt" = Inst' Hlt
         | otherwise  = error "Illegal instruction"
        
        instructions :: Lexer String
        instructions =
            string "ste"
            <|> string "mov"
            <|> string "nop"
            <|> string "hlt"

keyword :: Lexer Token
keyword = str2kw <$> keywords
    where
        str2kw :: String -> Token
        str2kw k
         | k == "entry" = Keyword' Entry
         | k == "bits" = Keyword' Bits
         | otherwise = error "Unknown keyword"

        keywords :: Lexer String
        keywords =
            string "entry"
            <|> string "bits"

newtype Lexer a = Lexer { runlexer :: String -> Maybe (a,String) }

instance Functor Lexer where
    fmap :: (a -> b) -> Lexer a -> Lexer b
    fmap f l = Lexer $ \x ->
        case lex l x of
            Just (a,xs) -> Just (f a,xs)
            _           -> Nothing

instance Applicative Lexer where
    pure :: a -> Lexer a
    pure a = Lexer $ \xs -> Just (a,xs)
    (<*>) :: Lexer (a -> b) -> Lexer a -> Lexer b
    fab <*> fa = Lexer $ \xs -> 
        case lex fab xs of
            Nothing     -> Nothing
            Just (a,xs')   -> lex (fmap a fa) xs'

join :: Lexer (Lexer a) -> Lexer a
join ma = Lexer $ \x ->
    case lex ma x of
        Nothing -> empty
        Just (mb,x') -> lex mb x'

instance Monad Lexer where
    return :: a -> Lexer a
    return = pure
    (>>=) :: Lexer a -> (a -> Lexer b) -> Lexer b
    ma >>= f = join $ Lexer $ \x ->
        case lex ma x of
            Nothing     -> Nothing
            Just (a,xs) -> Just (f a,xs)

-- label :: Lexer Token
-- label = do Label' . Label <$> (anyidentifier `unless` (== "")) 

label :: Lexer Token
label = do Label' . Label <$> (identifier `unless` (== "")) 

suchthat :: Lexer a -> (a -> Bool) -> Lexer a
suchthat m p = do
    a <- m
    guard $ p a
    return a

unless :: Lexer a -> (a -> Bool) -> Lexer a
unless m p = suchthat m (not <$> p)

instance Alternative Lexer where
    empty :: Lexer a
    empty = Lexer $ const Nothing
    some :: Lexer a -> Lexer [a]
    some v = some_v
      where
        many_v = some_v <|> pure []
        some_v = liftA2 (:) v many_v

    -- many :: Lexer a -> Lexer [a]
    many v = many_v
      where
        many_v = some_v <|> pure []
        some_v = liftA2 (:) v many_v
--   (<|>) :: Lexer a -> Lexer a -> Lexer a
    a <|> b = Lexer $ \x ->
        case lex a x of
            Nothing -> lex b x
            y       -> y

lex :: Lexer a -> String -> Maybe (a,String)
lex (Lexer f) = f

char :: Char -> Lexer Char
char c = Lexer $ \case
    (x:xs)
     | x == c   -> Just (c,xs)
    _           -> Nothing

string :: String -> Lexer String
string = traverse char

-- Combinators
anychar :: Lexer Char
anychar = Lexer $ \case
    (x:xs)      -> Just (x,xs)
    _           -> Nothing

anystring :: Lexer String
anystring = some anychar

anyidentifier :: Lexer String
anyidentifier = anystring `suchthat` all (`elem` valid)
 where
    valid :: String
    valid =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
         <> "0123456789'_$"

identifier :: Lexer String
identifier = stringuntil (notseparator) --`suchthat` all (`elem` valid)
 where
    valid :: String
    valid =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
         <> "0123456789'_$"

stringuntil :: (Char -> Bool) -> Lexer String
stringuntil p = stringuntil' p ""

stringuntil' :: (Char -> Bool) -> String -> Lexer String
stringuntil' p xs = do
    x <- anychar
    if not (p x) then
        refund x $ reverse $ x:xs
    else
        stringuntil' p (x:xs)

refund :: Char -> String -> Lexer String
refund c s = Lexer $ \xs -> case s of
    []  -> empty
    _   -> Just (reverse . safetail $ reverse s,c:xs)
        where
            safetail :: String -> String
            safetail = drop 1

notseparator :: Char -> Bool
notseparator '\n' = False
notseparator ':' = False
notseparator ',' = False
notseparator ';' = False
notseparator ' ' = False
notseparator _ = True

lexfile :: String -> [Token]
lexfile s = lexfile' s []

lexfile' :: String -> [Token] -> [Token]
lexfile' xs ts = case lex assembly (f xs) of
    Nothing       -> error "Parse error"
    Just (Eof',_) -> reverse $ filter (/= Space') (Eof':ts)
    Just (t,xs')  -> lexfile' xs' (t:ts)
    where
        f :: String -> String
        f = filter (/= '\r')

lexio :: FilePath -> IO [Token]
lexio fp = do
    xs <- readFile fp
    return $ lexfile xs

printtok :: FilePath -> IO ()
printtok fp = do
    ts <- lexio fp
    let xs = concatMap showln ts
    putStrLn xs
        where
            showln :: Show a => a -> String
            showln a = show a <> "\n"

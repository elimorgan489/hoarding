{-# language BangPatterns #-}
{-# language DerivingVia #-}
{-# language FlexibleInstances #-}
{-# language GeneralisedNewtypeDeriving #-}
{-# language InstanceSigs #-}
{-# language KindSignatures #-}
{-# LANGUAGE LambdaCase #-}
{-# OPTIONS_GHC -Wno-orphans #-}
{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
{-# LANGUAGE RecordWildCards #-}
module Compiler where

import Prelude hiding (Word)
import Lexer
 (
    Token(..), Label(..), Keyword(..),
    Word, Inst (..), Reg (..), Bitspace (..),
    lexio
 )
import Control.Applicative (Alternative(..))
import Control.Monad (guard)
import Data.Word (Word8)
-- import Data.Bits (shiftR)
-- import GHC.Bits ((.&.))
import Penguin
 (
    Bytearray(..), Header(..),
    pack, unword16, unword16', emptyarr,
    emptyhdr, wrpenguin, mkpenguin
 )

ast :: Asm
ast = keyword <|> label <|> eo <|> instruction

instance Alternative (Either String) where
    empty :: Either String a
    empty = Left ""
    (<|>) :: Either String a -> Either String a -> Either String a
    ea <|> _ = ea

newtype Parser a = Parser
    {
         parse :: [Token] -> Either String (a, [Token])
    }

instance Functor Parser where
    fmap :: (a -> b) -> Parser a -> Parser b
    fmap f p = Parser $ \x ->
        case parse p x of
           Left e       -> Left e
           Right (a,ts) -> Right (f a,ts)

instance Applicative Parser where
    pure :: a -> Parser a
    pure a = Parser $ \x -> Right (a,x)
    (<*>) :: Parser (a -> b) -> Parser a -> Parser b
    p1 <*> p2 = Parser $ \x ->
        case parse p1 x of
            Left e            -> Left e
            Right (f,ts)      -> case parse p2 ts of
                Left e'           -> Left e'
                Right (t,ts')     -> Right (f t,ts')

instance Monad Parser where
    return :: a -> Parser a
    return = pure
    (>>=) :: Parser a -> (a -> Parser b) -> Parser b
    ma >>= f = join $ Parser $ \x ->
        case parse ma x of
            Left e        -> Left e
            Right (a,ts)  -> Right (f a,ts)

instance Alternative Parser where
    (<|>) :: Parser a -> Parser a -> Parser a
    ma <|> mb = Parser $ \x ->
        case parse ma x of
            Right (a,ts)    -> Right (a,ts)
            _               -> parse mb x

    -- empty :: forall (f :: * -> *) a. Alternative f => f a
    empty :: Parser a
    empty = Parser $ const $ Left "Unknown parse error"
    some :: Parser a -> Parser [a]
    some v = some_v
      where
        many_v = some_v <|> pure []
        some_v = liftA2 (:) v many_v


join :: Parser (Parser a) -> Parser a
join ma = Parser $ \x ->
    case parse ma x of
        Left _       -> empty
        Right (a,ts) -> parse a ts

data Memory =
    MLabel Label
    | MAddr Word
    deriving stock Show

data Target =
    TReg Reg
    | TMem Memory
    | TInt Word
    deriving stock Show

type Asm = Parser Ast
data Ast =
    KEntry Memory
    | KBits Word
    | LLabel Label
    | DLabel Label
    | IMov Target Target
    | ISte | IStg | ISth | IStl
    | ICle | IClg | IClh | ICll
    | INop | IHlt
    | Eol | Eof
    deriving stock Show

objhdr :: [Ast] -> Header
objhdr as = objhdr' as emptyhdr

objhdr' :: [Ast] -> Header -> Header
objhdr' [] h' = verify h'
 where
    verify :: Header -> Header
    verify h = h{hentry = hentry'', hbits = hbits''}
        where
            verify' :: String -> Word -> Word
            verify' s w = if w > 0 then w else error $
                s <> " is not set"
            hentry'' = verify' "entry" (hentry h)
            hbits'' = verify' "bits" (hbits h)

objhdr' [a] !h = objhdr' [] $ case a of
    (KEntry (MLabel l)) -> error $ "Unresolved label: " <> show l
    (KEntry (MAddr w))  -> h{ hentry = w }
    (KBits 16)          -> h{ hbits = 16 }
    (KBits _)           -> error "Only 16bit Assembly supported"
    _                   -> h
objhdr' (a:as) !h = objhdr' as $ case a of
    (KEntry (MLabel l)) -> error $ "Unresolved label: " <> show l
    (KEntry (MAddr w))  -> h{ hentry = w }
    (KBits 16)          -> h{ hbits = 16 }
    (KBits _)           -> error "Only 16bit Assembly supported"
    _                   -> h

keyword :: Asm
keyword = err $ Parser $ \case
    ((Keyword' Entry):(Label' x):ts)  -> Right (KEntry (MLabel x),ts)
    ((Keyword' Entry):_)              -> Left
        "entry: Bad argument"
    ((Keyword' Bits):(Int' x):ts)     -> Right (KBits x,ts)
    ((Keyword' Bits):_)               -> Left
        "bits: Bad argument"
    (t:_)                             -> Left $
        "Expected 'entry' but got " <> show t
    []                                -> Left "Unexpected end of file"
    where
        -- err :: Asm -> Asm
        -- err m = catch m handler

        -- handler :: (HasCallStack, Exception e) => e -> Asm
        -- handler e = Parser $ const $ Left $ show e
        err = id

consume :: Parser Token
consume = Parser $ \case
    (t:ts)  -> Right (t,ts)
    _       -> empty

label :: Asm
label = do
    lbl <- consume
    cln <- consume
    case (lbl,cln) of
        (Label' lbl',Colon')    -> return $ DLabel lbl'
        _                               -> empty

mov :: Asm
mov = do
    i <- consume
    dst <- consume
    comma <- consume
    src <- consume
    guard (comma == Comma')
    case (i,dst,src) of
        -- source = integer constant / memory address
        (Inst' Mov,Reg' r,Int' i')  -> return $ IMov
            (TReg r) (TInt i')
        (Inst' Mov,Label' l,Int' i') -> return $ IMov
            (TMem (MLabel l)) (TInt i')
        (Inst' Mov,Int' i'',Int' i') -> return $ IMov
            (TMem (MAddr i'')) (TInt i')
        
        -- source = register
        (Inst' Mov,Reg' r,Reg' r')  -> return $ IMov
            (TReg r) (TReg r')
        (Inst' Mov,Label' l,Reg' r') -> return $ IMov
            (TMem (MLabel l)) (TReg r')
        (Inst' Mov,Int' i'',Reg' r') -> return $ IMov
            (TMem (MAddr i'')) (TReg r')
        
        -- source = memory (label)
        (Inst' Mov,Reg' r,Label' l')  -> return $ IMov
            (TReg r) (TMem (MLabel l'))
        (Inst' Mov,Label' l,Label' l') -> return $ IMov
            (TMem (MLabel l)) (TMem (MLabel l'))
        (Inst' Mov,Int' i'',Label' l') -> return $ IMov
            (TMem (MAddr i'')) (TMem (MLabel l'))
        _                           -> empty

setandclear :: Asm
setandclear = do
    i <- consume
    case i of
        (Inst' Ste)  -> return ISte
        (Inst' Stg)  -> return IStg
        (Inst' Sth)  -> return ISth
        (Inst' Stl)  -> return IStl
        (Inst' Cle)  -> return ICle
        (Inst' Clg)  -> return IClg
        (Inst' Clh)  -> return IClh
        (Inst' Cll)  -> return ICll
        (Inst' Nop)  -> return INop
        (Inst' Hlt)  -> return IHlt
        _            -> empty

instruction :: Asm
instruction = mov <|> setandclear

eo :: Asm
eo = do
    t <- consume
    case t of
        Eol'    -> return Eol
        Eof'    -> return Eof
        _       -> empty

data Addr =
    Addr (Label,Word)
    | NoAddr
    deriving stock Show
type AddrTable = [Addr]

mkaddrtable :: [Ast] -> AddrTable
mkaddrtable asts = mkaddrtable' asts 0 []

mkaddrtable' :: [Ast] -> Word -> AddrTable -> AddrTable
mkaddrtable' [] _ !addrtable = cleanup addrtable
 where
    cleanup :: AddrTable -> AddrTable
    cleanup as = reverse [a | a <- as, hasaddr a]
    hasaddr :: Addr -> Bool
    hasaddr (Addr _) = True
    hasaddr _ = False
mkaddrtable' (ast':asts) !n !addrtable =
    mkaddrtable' asts (n + (countast ast')) ((f ast' n):addrtable)
 where
    f :: Ast -> Word -> Addr
    f (DLabel l) n' = Addr (l,n')
    f _ _ = NoAddr

substitute :: AddrTable -> Ast -> Ast
substitute addrtable (KEntry (MLabel l)) =
    case atlookup addrtable l of
        Addr (_,a)  -> KEntry (MAddr a)
        _           -> error $ "Parse error (no such label: "
                        <> show l <> ")"
substitute addrtable (IMov (TMem (MLabel l)) t) =
    case atlookup addrtable l of
        Addr (_,a') -> IMov (TMem (MAddr a')) t
        _       -> error $ "Parse error (no such label: "
                    <> show l <> ")"
substitute addrtable (IMov t (TMem (MLabel l))) =
    case atlookup addrtable l of
        Addr (_,a') -> IMov t (TMem (MAddr a'))
        _       -> error $ "Parse error (no such label: "
                    <> show l <> ")"
substitute _ ast' = ast'

sbox :: AddrTable -> [Ast] -> [Ast]
sbox addrtable as = sbox' addrtable as []

sbox' :: AddrTable -> [Ast] -> [Ast] -> [Ast]
sbox' _ [] !as' = reverse as'
sbox' addrtable (a:as) !as' =
    sbox' addrtable as ((substitute addrtable a):as')

atlookup :: AddrTable -> Label -> Addr
atlookup ((Addr (l',a')):as) l
                             | l' == l = Addr $ (l',a')
                             | otherwise = atlookup as l
atlookup _ _ = NoAddr

countast :: Ast -> Word
countast (KEntry _) = 12
countast (KBits _ ) = 0
countast (LLabel _) = 0
countast (DLabel _) = 0
countast (IMov _ _) = 3
countast ISte = 1
countast IStg = 1
countast ISth = 1
countast IStl = 1
countast ICle = 1
countast IClg = 1
countast IClh = 1
countast ICll = 1
countast INop = 1
countast IHlt = 1
countast Eol = 0
countast (Eof) = 0

data Machinecode =
    NoMC
    | Machinecode Bytearray
    deriving stock Show

machinecode :: Ast -> Machinecode
machinecode INop = Machinecode 0x01
machinecode IHlt = Machinecode 0x02
machinecode ISte = Machinecode 0x10
machinecode ICle = Machinecode 0x11
machinecode IStg = Machinecode 0x12
machinecode IClg = Machinecode 0x13
machinecode ISth = Machinecode 0x14
machinecode IClh = Machinecode 0x15
machinecode IStl = Machinecode 0x16
machinecode ICll = Machinecode 0x17
machinecode (IMov (TReg r) x) = movr r x
machinecode (IMov (TMem (MAddr a)) (TReg x)) = mova a x
machinecode _ = NoMC

machinecodes :: [Machinecode] -> Machinecode
machinecodes xs = machinecodes' (filter f xs) $ Machinecode emptyarr
 where
    f :: Machinecode -> Bool
    f NoMC  = False
    f _     = True

machinecodes' :: [Machinecode] -> Machinecode -> Machinecode
machinecodes' [] m = m
machinecodes' [x] m@(Machinecode (Bytearray ys)) =
    machinecodes' [] (f x ys)
     where
        f :: Machinecode -> [Word8] -> Machinecode
        f (Machinecode x') ys' =
            case x' of
                (Bytearray [])      -> m
                (Bytearray [x''])   ->
                    Machinecode $ Bytearray $ (x'':ys')
                (Bytearray xs')     ->
                    Machinecode $ Bytearray $ (xs' ++ ys')
machinecodes' ((Machinecode x):xs) m@(Machinecode (Bytearray ys)) =
    case x of
        (Bytearray []) ->
            machinecodes' xs m
        (Bytearray [x']) ->
            machinecodes' xs $ Machinecode $ Bytearray (x':ys)
        (Bytearray xs') ->
            machinecodes' xs $ Machinecode $ Bytearray (xs' ++ ys)

movr :: Reg -> Target -> Machinecode
movr r' (TInt i) =
    case r' of
        (Ax Whole)  -> Machinecode $ pack $ 0x08:unword16 i
        (Bx Whole)  -> Machinecode $ pack $ 0x09:unword16 i
        (Cx Whole)  -> Machinecode $ pack $ 0x0a:unword16 i
        (Dx Whole)  -> Machinecode $ pack $ 0x0b:unword16 i
        (Ax Higher) -> Machinecode $ pack $
            um ISth:0x08:unword16' (i `mod` 256)
        (Bx Higher) -> Machinecode $ pack $
            um ISth:0x09:unword16' (i `mod` 256)
        (Cx Higher) -> Machinecode $ pack $
            um ISth:0x0a:unword16' (i `mod` 256)
        (Dx Higher) -> Machinecode $ pack $
            um ISth:0x0b:unword16' (i `mod` 256)
        (Ax Lower) -> Machinecode $ pack $
            um IStl:0x08:unword16' (i `mod` 256)
        (Bx Lower) -> Machinecode $ pack $
            um IStl:0x09:unword16' (i `mod` 256)
        (Cx Lower) -> Machinecode $ pack $
            um IStl:0x0a:unword16' (i `mod` 256)
        (Dx Lower) -> Machinecode $ pack $
            um IStl:0x0b:unword16' (i `mod` 256)
        (Ax Pointer)   -> Machinecode $ pack $ 0x0d:unword16 i
        (Bx Pointer)   -> Machinecode $ pack $ 0x0e:unword16 i
        (Cx Pointer)   -> Machinecode $ pack $ 0x0f:unword16 i
        _              -> error "Illegal instruction"

mova :: Word -> Reg -> Machinecode
mova w r' = case r' of
    (Ax Whole)  -> Machinecode $ pack $ 0x0d:unword16 w
    (Bx Whole)  -> Machinecode $ pack $ 0x0e:unword16 w
--  Note: mov [addr],cx is not available (nor is cl or ch)
    (Cx _)      -> error "Bad combination, register and opcode"
    (Dx Whole)  -> Machinecode $ pack $ 0x0f:unword16 w
    (Ax Lower)  -> Machinecode $ pack $ um IStl:0x0d:unword16 w
    (Bx Lower)  -> Machinecode $ pack $ um IStl:0x0e:unword16 w
    (Dx Lower)  -> Machinecode $ pack $ um IStl:0x0f:unword16 w
    (Ax Higher)  -> Machinecode $ pack $ um ISth:0x0d:unword16 w
    (Bx Higher)  -> Machinecode $ pack $ um ISth:0x0e:unword16 w
    (Dx Higher)  -> Machinecode $ pack $ um ISth:0x0f:unword16 w
--  Note: mov [addr],[ax] is invalid (and so are all ptr regs)
    (Ax Pointer) -> error "Bad combination, register and opcode"
    (Bx Pointer) -> error "Bad combination, register and opcode"
    (Dx Pointer) -> error "Bad combination, register and opcode"
    _            -> error "Illegal instruction"

um :: Ast -> Word8
um y = case machinecode y of
    (Machinecode (Bytearray [x']))    -> x'
    _                                 -> error "usage err"

parsefile :: [Token] -> [Ast]
parsefile ts = parsefile' ts []

parsefile' :: [Token] -> [Ast] -> [Ast]
parsefile' ts !as = case parse ast ts of
    Left err        -> error err
    Right (Eof,_)   -> reverse as
    Right (a,ts')   -> parsefile' ts' (a:as)

parseio :: FilePath -> IO [Ast]
parseio fp = do
    as <- lexio fp
    return $ parsefile as

compile :: FilePath -> FilePath -> IO ()
compile input output = do
    aast <- parseio input
    let
        at = mkaddrtable aast
        ast' = sbox at aast
        mc = machinecodes (map machinecode ast')
        hdr = objhdr ast'
        mc' = case mc of
            (Machinecode x) -> x
        penguin = mkpenguin hdr mc'
    wrpenguin output penguin

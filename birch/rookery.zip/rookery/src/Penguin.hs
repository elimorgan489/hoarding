{-
 - PENGUIN binary executable file format for the Birdnest arch
-}
{-# language InstanceSigs #-}
{-# language GeneralisedNewtypeDeriving #-}
{-# language FlexibleInstances #-}
{-# LANGUAGE DerivingStrategies #-}
{-# OPTIONS_GHC -Wno-orphans #-}
module Penguin where
import Prelude hiding (Word)
import Lexer (Word)
import Data.Word (Word8)
import Data.Bits ((.&.))
import GHC.Bits (shiftR)
import Data.ByteString as B hiding (map)
import Data.ByteString.Internal (c2w)

instance Num [Word8] where
  (a:as) + (b:bs) = map (+a) as + map (+b) bs
  [] + b = b
  a + [] = a
  (a:as) * (b:bs) = map (*a) as + map (*b) bs
  [] * b = b
  a * [] = a
  abs (a:as) = abs a:map abs as
  abs _ = [0]
  signum (a:as) = signum a:map signum as
  signum _ = [0]
  fromInteger x = [fromIntegral x]
  negate (a:as) = negate a:map negate as
  negate _ = [0]

newtype Bytearray = Bytearray [Word8]
    deriving stock Eq
    deriving newtype Num
instance Show Bytearray where
    show (Bytearray arr) = show arr

class ByteArray a where
    pack :: a -> Bytearray
    unword16 :: a -> [Word8]
    unword16' :: a -> [Word8]
    unword16 _ = []
    unword16' _ = []
    {-# minimal pack #-}

unba :: Bytearray -> [Word8]
unba (Bytearray arr) = arr

emptyarr :: Bytearray
emptyarr = Bytearray []

instance ByteArray [Word8] where
    pack :: [Word8] -> Bytearray
    pack [] = Bytearray []
    pack (x:xs) = Bytearray $ x:unba (Penguin.pack xs)

instance ByteArray Word where
    pack :: Word -> Bytearray
    pack = Bytearray . unword16
    unword16 :: Word -> [Word8]
    unword16 w16 = [c, d]
        where
            a :: Word
            a = shiftR (fromIntegral (w16 .&. 0xff00)) 8
            b :: Word
            b = fromIntegral (w16 .&. 0xff)
            c :: Word8
            c = fromIntegral a
            d :: Word8
            d = fromIntegral b
    unword16' :: Word -> [Word8]
    unword16' w16 = [0, b]
        where
            b :: Word8
            b = fromIntegral (w16 .&. 0xff)

data Header = Header
 {
  hentry   :: Word
 ,hbits    :: Word
 }
 deriving stock Show

emptyhdr :: Header
emptyhdr = Header 0 0

data PENGUIN = PENGUIN
 { magic    :: String
 , entry    :: Word
 , bits     :: Word
 , content  :: Bytearray
 }
 deriving stock Show

mkpenguin :: Header -> Bytearray -> PENGUIN
mkpenguin h = PENGUIN "PENGUIN" (hentry h) $ hbits h

str2ba :: String -> [Word8]
str2ba s = map c2w s <> 0

wrpenguin :: FilePath -> PENGUIN -> IO ()
wrpenguin fp p = do
    let
        mgc = magic p
        hdr = (unword16 $ entry p,unword16 $ bits p)
        arr = case content p of
            (Bytearray xs)  -> xs
        bytes = str2ba mgc
            <> fst hdr
            <> snd hdr
            <> arr
        bs = B.pack bytes
    B.writeFile fp bs

-- wrpenguin' :: FilePath -> Header -> Bytearray -> IO ()
-- wrpenguin' fp hdr arr = do
--     let
--         hdr' = (unword16 $ hentry hdr,unword16 $ hbits hdr)
--         arr' = case arr of
--             (Bytearray xs)  -> xs
--         bytes = fst hdr'
--             <> snd hdr'
--             <> arr'
--         bs = B.pack bytes
--     B.writeFile fp bs

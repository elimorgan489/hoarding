/* ccapi.c */
#include <ccapi.h>

/* EXAMPLE:
 import(encrypt);
*/

void zero(int8* buf, int16 size) {
    __asm("pusha");
    __asm("xor %ecx,%ecx");
    __asm("movw %0,%%cx"::"r"(size));
    __asm("mov %0,%%edi"::"m"(buf));
    __asm("xor %eax,%eax");

    __asm("rep stosb");
    __asm("popa");

    return;
}

args *empty() {
    static args ret = {
        .argc = 1
    };

    return &ret;
}

export args *mkargs(...) {
    int *p;
    void *arr[5];
    int32 argc;
    int16 size;
    args *a;
    int8 n;

    size = sizeof(void*) * 5;
    zero($1 &arr, size);
    argc = $4 0;
    Args(p);

    if (!p)
        return (args *)0;
    else if (!*p)
        return empty();

    do {
        *(arr + argc++) = (void *)*p;
    } while (*p++);
    argc--;

    if (!argc)
        return (args *)0;
    
    size = (argc * sizeof(void*)) + sizeof(struct s_args);
    a = (args *)malloc($i size);
    if (!a)
        return (args *)0;
    else
        zero($1 a, size);
    
   for (n=0; n<argc; n++)
        a->argv[n] = arr[n];
   a->argc = ++argc;

    return a;
}

void printargs_(int8 *ident, args *a) {
    int32 n;
    // int32 *x;

    printf("%s:\n  argc    = %d\n", $c ident, a->argc);
    for (n = 0; n < (a->argc-1); n++)
        printf("  argv[%d] = %p\n", $i n, a->argv[n]);
   
    return;
}

/*

EXAMPLE:

int main() {
    int32 output;

    asmcall(encrypt, output, 3, 8, 0);
    printf("output = %d\n", $i output);

    return 0;
}
*/

#pragma GCC diagnostic pop
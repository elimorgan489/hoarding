/* ccapi.h */
#pragma once
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#pragma GCC diagnostic push

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

typedef unsigned char int8;
typedef unsigned short int int16;
typedef unsigned int int32;
typedef unsigned long long int int64;

#define export __attribute__((visibility("default")))

#define $c (char *)
#define $i (int)
#define $1 (int8 *)
#define $2 (int16)
#define $4 (int32)
#define $8 (int64)

#define Args(x) \
    __asm("push %ebx"); \
    __asm("mov %ebp,%ebx"); \
    __asm("add $0x08,%ebx"); \
    __asm("mov %%ebx,%0":"=r"(x)); \
    __asm("pop %ebx")
#define printargs(x)        printargs_($1 # x, x)
#define import(x)           extern int32 x (args*)
#define asmcall(f,o,i...) do { \
    int32 (*_p)(args*); \
    args *_args; \
 \
    _p = &((f)); \
    _args = mkargs(i); \
 \
    if (!_args) \
        (o) = 0; \
    else \
        (o) = _p((args *)_args); \
} while (false)

struct s_args {
    int32 argc;
    void *argv[];
};
typedef struct s_args args;

/* constructors */
export args *mkargs(...);
args *empty(void);

void printargs_(int8*,args*);
void zero(int8*,int16);
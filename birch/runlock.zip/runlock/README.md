# Runlock v1.0
### by @dr-Jonas-Birch YT

Runlock adds secure password protection to any Linux ".exe file" (elf binary executable).

### Build

> bash$ npm install runlock
> bash$ cd node_modules/runlock
> bash$ make

### Run

> bash$ ./runlock /path/to/program outputfile
> bash$ chmod 755 outputfile

The software will produce a 32bit statically linked elf binary executable which should be able to run from any system. I recommend that you use this program on statically linked binaries but it works just as well on dynamic ones.

# Dependencies

* gcc  >= 14.2.0
* nasm >= 2.16.01
* birchutils >= 1.0
    (available at the repo[1])
* 32bit Linux operating system
    (the hardware cpu can be 64bit though)

### Security level

If you choose a secure password, then the password protection is unbreakable even with powerful hardware resources and a lot of time. A bold statement, I know, but I have designed the crypto things myself (both the hash, the kdf and the stream cipher are well-known ciphers but modified for increased security).

### If it gives "wrong password" when it shouldn't

The alignment is probably wrong. Change the "malign" constant at the top of runlock.asm, recompile and run runlock again. It might require different "malign" values for different input binaries and for same input binaries but different passwords.

# References

[1]
https://repo.doctorbirch.com
My code repo

# License

Runlock is licenced as MIT with the caveat that you're not allowed to use this for malign purposes. Make sure to always refer to my Youtube channel @dr-Jonas-Birch when distributing this software or derivates of this software.

/* fsd.c */
#include "fsd.h"

        istruc termios
            int32 c_iflag,     dd 0x00
            int32 c_oflag,     dd 0x00
            at .c_cflag,     dd 0x00
            at .c_lflag,     dd 0x00
            at .c_line,      db 0x00
            at .c_cc,        db 0x00
        iend

void usage(int8 *arg) {
    fprintf(stderr, "%s <source> <destination>\n", arg);

    return;
}

void changeecho(bool enabled) {
    struct termios t;

    tcgetattr(0, &t);
    if (enabled)
        t.c_lflag &= ECHO;
    else
        t.c_lflag |= ECHO;

    tcsetattr(0, 0, &t);

    return;
}
int8 *readkey(int8 *prompt) {
    int8 buf[256];
    int8 *p;
    int8 size, idx;

    printf("%s ", prompt);
    fflush(stdout);

    changeecho(false);
    memset(buf, 0, 256);
    read(0, (char *)buf, 255);
    size = (int8)strlen((char *)buf);
    idx = size -1;
    p = (int8 *)buf + idx;
    *p = 0;

    p = (int8 *)malloc(size);
    assert(p);
    strncpy((char *)p, (char *)buf, idx);
    changeecho(true);

    return p;
}

int main(int argc, char *argv[]) {
    int8 *srcfile, *dstfile;
    int8 *tmp;

    if (argc < 3) {
        usage((int8 *)*argv);
        return -1;
    }

    srcfile = (int8 *)argv[1];
    dstfile = (int8 *)argv[2];

    tmp = readkey((int8 *)"Key:");
    printf("Key is %s\n", (char *)tmp);

    return 0;

/*
    readkey();
    initcrypto();
    decryptint16();
    skipbytes();
    readhash();
    verifyhash();
    decryptrestoffile();
    */
}









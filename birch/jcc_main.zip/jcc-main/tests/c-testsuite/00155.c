
int
main(void)
{
	sizeof((int) 1);
	return 0;
}


// line comment

int
main()
{
	/*
		multiline
		comment
	*/
	return 0;
}

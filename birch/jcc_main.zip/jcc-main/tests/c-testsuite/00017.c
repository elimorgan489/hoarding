int
main()
{
	struct { int x; int y; } s;

	s.x = 3;
	s.y = 5;
	return s.y - s.x - 2;
}

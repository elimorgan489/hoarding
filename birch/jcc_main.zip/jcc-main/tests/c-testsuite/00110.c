extern int x;
int x;

int
main()
{
	return x;
}

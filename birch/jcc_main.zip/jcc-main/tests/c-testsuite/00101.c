int
main()
{
  int c;
  c = 0;
  do
    ;
  while (0);
  return c;
}

#define F(a, b) a
int
main()
{
	return F(, 1) 0;
}

#if 0
X
#elif 0
X
#elif 1
int x = 0;
#endif

int
main()
{
	return x;
}

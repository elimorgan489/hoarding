int
main()
{
	int a = 0;
	float f = a + 1;

	return f == a;
}

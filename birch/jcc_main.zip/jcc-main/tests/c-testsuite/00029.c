int
main()
{
	int x;

	x = 1;
	x = x ^ 3;
	return x - 2;
}


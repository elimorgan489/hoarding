// expected value: 10
int main() {
  if (1) {
    return 10;
  } else {
    return 5;
  }
}

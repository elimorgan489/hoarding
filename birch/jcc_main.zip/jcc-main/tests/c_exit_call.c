// expected value: 17

void exit(int code);

int main() { exit(17); }

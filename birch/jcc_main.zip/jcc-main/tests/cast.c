// expected value: 1

int main() {
  int a = (int)1;
  long b = (long)a;
  return (char)b;
}

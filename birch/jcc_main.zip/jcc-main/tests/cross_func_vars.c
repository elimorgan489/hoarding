// expected value: 3

void bar() {}

int main() {
  int a = 1;
  int b = 2;

  bar();

  return a + b;
}

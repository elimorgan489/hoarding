// expected value: 0
int main() {
  int a = 1;
  int b = 2;

  if (a == b) {
    return 1;
  } else {
    return 0;
  }
}

// expected value: 2
int main() {
  long a = 1;
  long b = 1;

  return a + b;
}

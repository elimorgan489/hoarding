// expected value: 1
int main() {
  int a = 1;
  return a;
}

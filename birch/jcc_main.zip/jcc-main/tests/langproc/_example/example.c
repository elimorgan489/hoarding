// stdout: Hello from RISC-V Test function produced value: 8.700000 Example function returned: 5

int f()
{
    return 5;
}

// expected value: 56
int main() { return 5 + 9 + 88 - 44 - 9 + 7; }

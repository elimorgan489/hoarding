// expected value: 0
// stdout: Hello, World!

#include <stdio.h>

int main() {
  printf("Hello, World!\n");
}

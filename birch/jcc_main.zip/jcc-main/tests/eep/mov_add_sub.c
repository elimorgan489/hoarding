// expected value: 0
int main() {
  int a = 1;
  int b = 2;

  int c = a + b;
  int d = a - b;
  return 0;
}

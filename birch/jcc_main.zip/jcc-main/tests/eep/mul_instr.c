// expected value: 35
int main() {
  int a = 7;
  int b = 5;

  int c = a * b;

  return c;
}

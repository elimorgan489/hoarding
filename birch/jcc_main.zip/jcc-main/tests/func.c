// expected value: 25

int hypot2(int a, int b) {
  return (a * a) + (b * b);
}

int main() { return hypot2(3, 4); }

// expected value: 20
int main() {
  int a = 1;
  int b = 10;
  return (a + a) * b;
}

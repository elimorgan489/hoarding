// expected value: 60
int main() {
  int question = 1;
  int answer;

  question = 1;

  if (question) {
    answer = 60;
  } else {
    answer = 100;
  }

  return answer;
}

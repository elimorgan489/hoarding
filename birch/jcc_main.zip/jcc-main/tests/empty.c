// expected value: 88

int main() {
  return 88;
}

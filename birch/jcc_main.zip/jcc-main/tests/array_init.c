// expected value: 12

int main() {
  int a[7] = {1, 2, 3, 4, 5, 6, 12};
  return a[6];
}

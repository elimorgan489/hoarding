// expected value: 16

int puts(const char *);
int main() { return 9 + 7; }

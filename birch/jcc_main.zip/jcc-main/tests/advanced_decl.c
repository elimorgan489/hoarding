// expected value: 54
int main() {
  int a = 1, b = 7;
  int z;
  z = 9;
  int k = 30;
  return k / 10 + 10 + a + b * b - z;
}

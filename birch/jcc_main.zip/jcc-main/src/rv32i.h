#ifndef RV32I_H
#define RV32I_H

#include "target.h"

#define RV32I_FUNCTION_ALIGNMENT (8)

extern const struct target RV32I_LINUX_TARGET;

#endif

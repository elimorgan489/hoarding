#ifndef MACOS_MACH_O_H
#define MACOS_MACH_O_H

#include "../target.h"

void write_macho(const struct build_object_args *args);

#endif

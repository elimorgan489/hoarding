#ifndef MACOS_LINK_H
#define MACOS_LINK_H

#include "../target.h"

enum link_result macos_link_objects(const struct link_args *args);

#endif

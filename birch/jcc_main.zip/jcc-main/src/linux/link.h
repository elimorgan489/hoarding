#ifndef LINUX_LINK_H
#define LINUX_LINK_H

#include "../target.h"

enum link_result linux_link_objects(const struct link_args *args);

#endif

#ifndef LINUX_ELF_H
#define LINUX_ELF_H

#include "../target.h"

void write_elf(const struct build_object_args *args);

#endif

#include "driver.h"

#include <stdlib.h>

int main(int argc, char **argv) {
  jcc_init();
  return jcc_main(argc, argv);
}

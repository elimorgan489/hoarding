#ifndef IR_ELIMINATE_PHI_H
#define IR_ELIMINATE_PHI_H

#include "ir.h"

void eliminate_phi(struct ir_func *irb);

#endif

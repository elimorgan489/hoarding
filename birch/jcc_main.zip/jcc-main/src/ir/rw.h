#ifndef IR_RW_H
#define IR_RW_H

// IR (de)?serialization

#if 0
#include "ir.h"

#include <stdio.h>

void ir_unit_ser(FILE *file, struct ir_unit *unit);
#endif

#endif

#ifndef DRIVER_H
#define DRIVER_H

// top-level code for running a compilation, parsing args, etc

void jcc_init(void);

int jcc_main(int argc, char **argv);

#endif

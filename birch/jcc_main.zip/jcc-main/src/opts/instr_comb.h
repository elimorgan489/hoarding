#ifndef INSTR_COMB_H
#define INSTR_COMB_H

#include "../ir/ir.h"

void opts_instr_comb(struct ir_unit *unit);

#endif

#ifndef CNST_FOLD_H
#define CNST_FOLD_H

#include "../ir/ir.h"

void opts_cnst_fold(struct ir_unit *unit);

#endif

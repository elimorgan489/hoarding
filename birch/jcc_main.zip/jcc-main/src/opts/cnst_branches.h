#ifndef CNST_BRANCHES_H
#define CNST_BRANCHES_H

#include "../ir/ir.h"

void opts_cnst_branches(struct ir_unit *unit);

#endif

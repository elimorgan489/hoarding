#ifndef PROMOTE_H
#define PROMOTE_H

#include "../ir/ir.h"

void opts_promote(struct ir_unit *unit);

#endif

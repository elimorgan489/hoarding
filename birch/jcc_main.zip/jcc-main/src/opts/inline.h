#ifndef INLINE_H
#define INLINE_H

#include "../ir/ir.h"

void opts_inline(struct ir_unit *unit);

#endif

# EEP - Read me!

You almost certainly do not want to be reading this directory. It is a (currently disabled) backend for EEP, the first-year CPU coursework at Imperial College London.

#ifndef EEP_OBJECT_H
#define EEP_OBJECT_H

#include "../target.h"

void write_eep(const struct build_object_args *args);

#endif

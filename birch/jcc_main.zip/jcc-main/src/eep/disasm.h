#ifndef EEP_DISASM
#define EEP_DISASM

void eep_debug_disasm(const char *filename);

#endif

/********** Generic argument parser **********/

// i sort of don't like the file name

#ifndef ARG_OPT_LIST
#error 'Must define `ARG_OPT_LIST`'
#else

#undef ARG_OPT_LIST

#endif

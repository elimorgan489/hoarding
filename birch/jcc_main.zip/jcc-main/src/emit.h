#ifndef EMIT_H
#define EMIT_H

#include "target.h"

#endif

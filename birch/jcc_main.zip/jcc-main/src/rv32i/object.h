#ifndef RV32I_OBJECT_H
#define RV32I_OBJECT_H

#include "../target.h"

void rv32i_write_object(const struct build_object_args *args);

#endif

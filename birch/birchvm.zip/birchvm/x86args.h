/*
 * x86args.h - Variable-length arguments macro for IA32
 *
 * <jonas@doctorbirch.com>
 *
 * 2024
 *
 */

#ifndef x86ARGS
#define x86ARGS
 
/*
 * Args :: Int* -> Int*
 */
#define Args(arg) \
 Program **_x; \
 __asm("mov %%ebp,%0":"=r"(_x)); \
 _x += 8; \
 arg = (Program **)_x

#endif
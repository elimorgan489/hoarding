/*
 * arcfour.h - C library for RC4 implementation
 *
 * dr Jonas Birch, 2024
 * 
 */

#define _GNU_SOURCE
#include <assert.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#define washcycles         500   // in millions
#define export              __attribute__((visibility("default")))
#define rc4decrypt(x,y,z)   rc4encrypt(x,y,z)
#define rc4uninit(x)        free(x)
#define rc4whitewash(x,y)   for (y=0; y<(washcycles*1000000); y++) \
                                (char volatile)rc4byte(x)

struct s_arcfour {
    unsigned char key[256];
    unsigned char s[256];
    unsigned short int i, j, k, size;
};
typedef struct s_arcfour Arcfour;

export Arcfour *rc4init(unsigned char*,const unsigned short int);
export unsigned char *rc4encrypt(Arcfour*,unsigned char*,
    const unsigned short int);
unsigned char rc4byte(Arcfour*);
/*
 * arcfour.c - RC4 implementation
 *
 * dr Jonas Birch, 2024
 * 
 */

#include "arcfour.h"

export Arcfour *rc4init(unsigned char *key, const unsigned short int keysize) {
    Arcfour *p;
    unsigned short int tmp1, tmp2;
    unsigned int i;

    assert(keysize > 1);
    assert(keysize < 257);

    if (!(p = (Arcfour *)malloc(sizeof(struct s_arcfour)))) {
        assert_perror(errno);
        return 0;
    }

    p->size = p->i = p->j = p->k
        = 0;
    memset(p->key, 0, 256);
    memset(p->s, 0, 256);
    memcpy(p->key, key, p->size);
    p->size = keysize;

    for (p->i = 0; p->i < 256; p->i++)
                p->s[p->i] = p->i;
    
    p->j = 0;
    for (p->i = 0; p->i < 256; p->i++) {
        tmp1 = p->i % p->size;
        tmp2 = p->key[tmp1];
        tmp1 = p->j + p->s[p->i] + tmp2;
        tmp2 = tmp1 % 256;

        p->j = tmp2;
        tmp1 = p->s[p->i];
        tmp2 = p->s[p->j];
        p->s[p->j] = tmp1;
        p->s[p->i] = tmp2;        
    }

    p->i=p->j = 0;
    rc4whitewash(p, i);

    return p;
}

unsigned char rc4byte(Arcfour *p) {
    unsigned short int tmp1, tmp2;
    unsigned char k;

    assert(p);
    p->i = (p->i + 1) % 256;
    p->j = (p->j + p->s[p->i]) % 256;

    tmp1 = p->s[p->i];
    tmp2 = p->s[p->j];
    p->s[p->j] = tmp1;
    p->s[p->i] = tmp2;

    tmp1 = p->s[p->i] + p->s[p->j];
    tmp2 = tmp1 % 256;
    k = p->s[tmp2];

    return k;
}

export unsigned char *rc4encrypt(Arcfour *p, unsigned char *src, const unsigned short int size) {
    unsigned char *dest;
    unsigned short int i;

    if (!(dest = (unsigned char *)malloc(size))) {
        assert_perror(errno);
        return 0;
    }

    for (i=0; i<size; i++)
        dest[i] = src[i] ^ rc4byte(p);

    return dest;
}

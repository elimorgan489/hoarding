/* temp.c - arcfour example util */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "arcfour.h"

unsigned char *show(unsigned char*,int);
int main(void);

unsigned char *show(unsigned char *str, int size) {
    int n, ms;
    unsigned char *p, *ret, *p2;

    ms = (size*2) + (size/2);
    ret = malloc(ms);
    for (n=(size+1), p=ret; --n; p++)
        *p = 0;

    for (n=(size+1), p=str, p2=ret; --n; p++) {
        sprintf((char *)p2, "%.02x", *p);
        p2 += 2;

        if ((size-n+1) && !((size-n+1)%2))
            *(p2++) = 0x20;
    }
    *p2 = 0;

    return ret;
}

int main() {
    Arcfour *rc4;
    unsigned short int ksize, tsize;
    unsigned char *from, *to, *to2, *key, *output;

    from = (unsigned char *)"Shall I compare thee to a summer's day?";
    key = (unsigned char *)"ApelsinApelsinApelsin"; // 168 bits
    ksize = strlen((char *)key);
    tsize = strlen((char *)from);

    rc4 = rc4init(key, ksize);

    printf("'%s'\n  -> ", from);

    to = rc4encrypt(rc4, from, tsize);
    if (!to) {
        perror("rc4encrypt");
        return -1;
    }

    output = show(to, 40);
    printf("%s...\n    -> ", output);
    rc4uninit(rc4);

    rc4 = rc4init(key, ksize);
    to2 = rc4decrypt(rc4, to, tsize);

    if (!to2) {
        perror("rc4decrypt");
        return -1;
    }

    printf("'%s'\n\n", to2);
    fflush(stdout);

    rc4uninit(rc4);
    free(to2);  
    free(output);
    free(to);

    return 0;
}
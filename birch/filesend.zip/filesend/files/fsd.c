/* fsd.c - filesend decrypt */
#include "filesend.h"

#define F fflush(stdout)
int main(int,char**);

int8 *readline(const char *prompt)
{
    int8 *p;
    int16 size;
    int8 buf[2056];

    printf("%s ", (!prompt)
        ? ">"
        : prompt
    ); F;

    memset(buf, 0, 2056);
    fgets((char *)buf, 2055, stdin);
    size = min((int16)strlen((char *)buf), 2048);
    p = (buf+size-1);

    while (size && ((*p == 10) || (*p == 13))) {
        *p-- = 0;
        size--;
    }

    if (!size)
        return 0;

    p = (int8 *)malloc(size);
    memset(p, 0, size);
    strncpy((char *)p, (char *)buf, size);

    return p;
}

void verify(...) {
    int16 offset;
    char buf[3];
    int8 *b;
    int n;

    //  o 00000000 00000000
    //  m 00000000 11111111
    // b1 01011100
    // b2 00111010

    *buf=*(buf+1)=*(buf+2) = 0;
    n = read(fd, buf, 2);
    assert(n == 2);

    b = rc4decrypt(rc4, buf, 2);
    assert(b != 0);

    offset = *b & 0x00FF
    offset = (offset << 8) | *(b+1);
}

int main(int argc, char *argv[]) {
    Arcfour *rc4;
    char *src, *dst;
    int srcfd, dstfd;
    int16 size;
    int8 *key;

    if (argc < 3) {
        fprintf(stderr, "Usage: %s SOURCE DESTINATION\n", *argv);
        return -1;
    }

    src = argv[1];
    dst = argv[2];
    key = readline("Passphrase: ");

    if (!key) {
        fprintf(stderr, "Aborted\n");
        return -1;
    }

    printf("Initializing..."); F;
    size = (int16)strlen((char *)key);
    rc4 = rc4init(key, size);

    if (!rc4) {
        fprintf(stderr, "failed\n");
        perror("rc4init");
        wipe(key, size);
        free(key);

        return -1;
    }
    else
        printf("done\n");

    srcfd = open(src, O_RDONLY);
    if (srcfd < 1) {
        perror("open");
        rc4uninit(rc4);
        wipe(key, size);
        free(key);

        return -1;
    }

    if (!verify(rc4, srcfd, key, size)) {
        fprintf(stderr, "Error: Bad encryption key\n");
        close(srcfd);

        rc4uninit(rc4);
        free(key); // No point of wiping

        return -1;
    }
    else
        printf("Key ok\n");

    wipe(key, size);
    free(key);
    dstfd = open(dst, O_WRONLY|O_CREAT, 0o600);

    if (dstfd < 1) {
        perror("open");

        close(srcfd);
        rc4uninit(rc4);

        return -1;
    }

    printf("Decrypting %s -> %s...", src, dst); F;
    decryptfile(rc4, dstfd, srcfd);
    printf("done\n");

    close(srcfd);
    close(dstfd);
    rc4uninit(rc4);

    return 0;
}
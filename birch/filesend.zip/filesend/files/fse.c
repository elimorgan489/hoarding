/* fse.c - filesend encrypt */
#include "filesend.h"

#define F fflush(stdout)
int main(int,char**);

bool echo(bool on) {
    struct termios t;

    tcgetattr(0, &t);
    t.c_lflag = (on) ?
        t.c_lflag | ECHO :
    t.c_lflag & ~ECHO;
    tcsetattr(0, 0, &t);

    return on;
}

int8 *readline(const char *prompt)
{
    int8 *p;
    int16 size;
    int8 buf[2056];

    printf("%s ", (!prompt)
        ? ">"
        : prompt
    ); F;

    echo(false);
    memset(buf, 0, 2056);
    fgets((char *)buf, 2055, stdin);
    echo(true);

    size = min((int16)strlen((char *)buf), 2048);
    p = (buf+size-1);

    while (size && ((*p == 10) || (*p == 13))) {
        *p-- = 0;
        size--;
    }

    if (!size)
        return 0;

    p = (int8 *)malloc(size);
    memset(p, 0, size);

    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wstringop-truncation"
        strncpy((char *)p, (char *)buf, size);
    #pragma GCC diagnostic pop

    return p;
}

void wipe(int8 *buf, int16 size) {
    int16 n, i;
    int8 *p;

    n=20;
    while (n--)
        for (i=size, p=buf; i; i--)
            *p++ = (n)
                ? 0
                : ((n*size) % 256);

    return;
}

int16 *rndsecure16() {
    char *buf;
    int16 *p;
    int16 n;

    if (!(buf = malloc(3))) {
        assert_perror(errno);
        exit(-1);
    }
    else
        *buf=*(buf+1)=*(buf+2) = 0;

    n = getrandom(buf, 2, GRND_RANDOM);
    p = (int16 *)buf;
    assert(*p && (n == 2));

    return p;

}

int8 *rndsecure8x(int16 size) {
    int8 *buf, *p;
    int16 n;

    if (!(buf = (int8 *)malloc(size))) {
        assert_perror(errno);
        exit(-1);
    }
    else
        memset((char *)buf, 0, size);

    n = getrandom((char *)buf, size, GRND_RANDOM|GRND_NONBLOCK);
    p = buf;
    if (n < size) {
        fprintf(stderr,
            "Warning: Entropy pool is low, this may take longer than usual.\n");
        if (n > 0) {
            p += n;
            size -= n;
        }

        n = getrandom((char *)p, size, GRND_RANDOM);
    }
    assert(n == size);

    return buf;
}

int8 *sha2(int8 *data, int16 size) {
    SHA2_CTX *ctx;
    int8 *buf;

    ctx = malloc(sizeof(SHA2_CTX));
    buf = malloc(32);
    assert(ctx && buf);

    memset(buf, 0, 32);
    SHA256Init(ctx);
    SHA256Update(ctx, data, size);
    SHA256Final(buf, ctx);
    free(ctx);

    return buf;
}

void padding(Arcfour *rc4, int fd, int16 size) {
    int8 enc, dec;
    int8 buf[2];
    int8 *pad, *p;
    int16 n;
    int x;

    n=size;
    *(buf+1) = 0;
    pad = rndsecure8x(size);

    p=pad;
    while (n--) {
        dec = *p++;
        enc = dec ^ rc4byte(rc4);
        *buf = enc;

        x = write(fd, (char *)buf, 1);
        assert(x == 1);
    }
    free(pad);

    return;
}

void keyhash(Arcfour *rc4, int fd, int8 *key, int16 size) {
    int x;
    int16 n;
    int8 *p, *hash;
    int8 buf[2];
    int8 dec, enc;

    n = 32;
    *(buf+1) = 0;
    hash = sha2(key, size);
    p = hash;

    while (n--) {
        dec = *p++;
        enc = dec ^ rc4byte(rc4);
        *buf = enc;
        x = write(fd, (char *)buf, 1);
        assert(x == 1);
    }
    free(hash);

    return;
}

void addheader(Arcfour *rc4, int fd, int8 *key, int16 size) {
    int16 *offset;
    int8 b[2], p[3];
    int n;

    //  o 11001001 10101001
    //  m 00000000 11111111
    // b1 01011100
    // b2 00111010

    *b=*(b+1) = 0;
    *p=*(p+1)=*(p+2) = 0;

    offset = rndsecure16();
    assert(*offset > 0);
    *b =     (*offset >> 8);
    *(b+1) = (*offset & 0x00FF);
    *p = rc4byte(rc4) ^ *b;
    *(p+1) = rc4byte(rc4) ^ *(b+1);
    *(p+2) = 0;

    n = write(fd, (char *)p, 2);
    assert(n == 2);

    padding(rc4, fd, *offset);
    keyhash(rc4, fd, key, size);
    free(offset);

    return;
}

void decryptfile(Arcfour *rc4, int dstfd, int srcfd) {
    return;
}

int main(int argc, char *argv[]) {
    Arcfour *rc4;
    char *src, *dst;
    int srcfd, dstfd;
    int16 size;
    int8 *key;

    if (argc < 3) {
        fprintf(stderr, "Usage: %s SOURCE DESTINATION\n", *argv);
        return -1;
    }

    src = argv[1];
    dst = argv[2];
    key = readline("Passphrase:");

    if (!key) {
        fprintf(stderr, "Aborted\n");
        return -1;
    }

    printf("\nInitializing..."); F;
    size = (int16)strlen((char *)key);
    rc4 = rc4init(key, size);

    if (!rc4) {
        printf("failed\n");
        perror("rc4init");
        wipe(key, size);
        free(key);

        return -1;
    }
    else
        printf("done\n");

    srcfd = open(src, O_RDONLY);
    if (srcfd < 1) {
        perror("open");
        rc4uninit(rc4);
        wipe(key, size);
        free(key);

        return -1;
    }

    dstfd = open(dst, O_WRONLY|O_CREAT, 00600);
    if (dstfd < 1) {
        perror("open");

        close(srcfd);
        rc4uninit(rc4);
        wipe(key, size);
        free(key);

        return -1;
    }

    printf("Encrypting %s -> %s...", src, dst); F;
    encryptfile(rc4, dstfd, srcfd, key, size);
    printf("done\n");

    close(srcfd);
    close(dstfd);
    rc4uninit(rc4);
    wipe(key, size);
    free(key);

    return 0;
}
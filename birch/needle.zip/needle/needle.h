/* needle.h */
#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <sched.h>

#define Registersize    8
#define Blocksize       (Registersize+1)
#define Mutextimeout    25
#define MAP_HUGE_2MB    (21 << MAP_HUGE_SHIFT)
#define MAP_HUGE_1GB    (30 << MAP_HUGE_SHIFT)
#define mb(x)           (1024*1024*(x))
#define kb(x)           (1024*(x))
#define export          __attribute__((visibility("default")))

/* note2self ' to _ conversion */
#define let(x)          (volatile void *)nalloc(# x)
#define get(x)          nget(# x)
#define put(x,y)        nput(# x, (void *)(y))
#define usecore(x,y)    CPU_ZERO(&(x)); \
                        CPU_SET((y), &(x)); \
                        sched_setaffinity(0, sizeof(cpu_set_t), &(x))
#define nfindident(x,n,y) \
    for (n=0; (n)<Heap.allocations; n++) \
        if (!strcmp((x), (char *)Heap.allocs[(n)].identifier)) { \
            y = (n); \
            break; \
        }

#define IdentChars      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'"
#define IdentOk         0
#define IdentTaken      1
#define IdentBadFormat  2
#define SizeofAllocs   76

typedef unsigned int int32;
typedef unsigned short int int16;
typedef unsigned char int8;

typedef unsigned char IdentResult;
typedef void (*cb)(int16);

struct s_memspace {
    bool initialized;
    int32 size;
    int32 capacity;
    int32 allocations;
    struct {
        int32 id;
        int8 identifier[64];
        int16 nid;
        bool lock;

    } *allocs;
    int8 *memspace;
};
typedef struct s_memspace Memspace;

bool islocked(int32);
void lock(int32);
void unlock(int32);
void nwaitforlock(int32);
export bool nput(char*,void*);
export void *nget(char*);
bool validchar(char);
IdentResult nverifyident(char*);
export void *nalloc(char*);
export void ninit(int32);
export void nuninit(void);
void nmain(int16,int16,cb);
int16 countcores(void);
export void awaitneedles(void);
export void spawn_single(int16,int16,cb);
export void spawn_multiple(cb);
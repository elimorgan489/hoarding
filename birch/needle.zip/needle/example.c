#include <needle.h>

extern Memspace Heap;
extern int16 nid;
extern int16 numneedles;

void _callback(int16 _nid) {
    unsigned long int n;

    n = (unsigned long int)get(myvar);
    n++;
    put(myvar, n);

    printf("[%d] Thread end\n", (unsigned int)nid);
    fflush(stdout);

    return;
}

int main(int argc, char *argv[]) {
    ninit(kb(20));
    let(myvar);

    printf("Spawning needlethreads...\n");
    fflush(stdout);

    spawn_multiple(&_callback);

    printf("\nAll threads terminated. Value of myvar is:\n");
    printf("%d\n", (unsigned int)((unsigned long int)get(myvar)));
    fflush(stdout);

    nuninit();

    return 0;
}
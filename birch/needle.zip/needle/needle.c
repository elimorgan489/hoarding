/* needle.c */
#include "needle.h"

export Memspace Heap = {0};
export int16 nid;
export int16 numneedles;

bool islocked(int32 idx) {
    int8 *p;

    p = (int8 *)Heap.memspace
        + (idx * Blocksize) +8;

    return (*p) ?
            true :
        false;
}

void lock(int32 idx) {
    int8 *p;
    int8 nid_, val;
    bool TooManyFailedAttempts;

    TooManyFailedAttempts = false;
    nid_ = (int8)(nid % 256);
    p = (int8 *)Heap.memspace + (idx * Blocksize) +8;
begin:
    *p = nid_;
    __asm__("nop;nop;nop;");
    val = (volatile unsigned char)(*p);

    if (val != nid_) {
        assert(!TooManyFailedAttempts);
        nwaitforlock(idx);
        TooManyFailedAttempts = true;
        goto begin;
    }

    return;
}
void unlock(int32 idx) {
    int8 *p;
    int8 val;
    bool TooManyFailedAttempts;

    TooManyFailedAttempts = false;
    p = (int8 *)Heap.memspace + (idx * Blocksize) +8;
begin:
    *p = 0x0;
    __asm__("nop;nop;nop;");
    val = (volatile unsigned char)(*p);

    if (val) {
        assert(!TooManyFailedAttempts);
        nwaitforlock(idx);
        TooManyFailedAttempts = true;
        goto begin;
    }

    return;
}

void nwaitforlock(int32 idx) {
    int c;

    c = 0;
    while (islocked(idx) && (c<Mutextimeout)) {
        usleep((rand() % 200000) + 50000);
        c++;
    }

    return;
}

export void *nget(char *identifier) {
    int32 idx, n;
    unsigned long int *p;
    unsigned long int v;

    idx = 0;
    nfindident(identifier, n, idx);
    assert(idx != -1);

    if (islocked(idx))
        nwaitforlock(idx);
    if (islocked(idx))
        return (void *)0;

    lock(idx);
    p = (unsigned long int *)((int8 *)Heap.memspace + (idx * Blocksize));
    v = (unsigned long int)*p;
    unlock(idx);

    return (void *)v; 
}

export bool nput(char *identifier, void *dst) {
    int32 idx, n;
    unsigned long int *p;

    idx = 0;
    nfindident(identifier, n, idx);
    assert(idx != -1);

    if (islocked(idx))
        nwaitforlock(idx);
    if (islocked(idx))
        return false;

    lock(idx);
    p = (unsigned long int *)((int8 *)Heap.memspace + (idx * Blocksize));
    *p = (unsigned long int)dst;
    unlock(idx);

    return true;
}

bool validchar(char c) {
    char *p;
    bool ret;

    ret = false;
    for (p=IdentChars; *p; p++)
        if (*p == c) {
            ret = true;
            break;
        }

    return ret;
}

IdentResult nverifyident(char *identifier) {
    bool exists;
    char *p;
    int32 n;

    exists = false;
    for (n=0; n<Heap.allocations; n++)
        if (!strcmp(identifier,
            (char *)Heap.allocs[n].identifier)) {
                exists = true;
                break;
            }

    if (exists)
        return IdentTaken;

    n = strlen(identifier);
    exists = true; // "exists" now means "is ok"

    for (p=identifier; *p && n; p++, n--)
        if (!validchar(*p)) {
            exists = false;
            break;
        }
    
    if (!exists)
        return IdentBadFormat;
    
    return IdentOk;
}

export void ninit(int32 _size) {
    int32 size;

    numneedles = 0;
    for (size=_size; (size % Blocksize); size++);
    assert(!(size % Blocksize));

    Heap.memspace = (int8 *)mmap((void *)0, (unsigned long int)size,
        PROT_READ|PROT_WRITE,
        MAP_SHARED|MAP_ANONYMOUS/*|MAP_FIXED*/
        |MAP_LOCKED|MAP_NORESERVE|MAP_STACK,
        -1, 0
    );

    if (Heap.memspace == (void *)-1)
        assert_perror(errno);
    
    Heap.size = size;
    Heap.capacity = (size / Blocksize);
    Heap.allocations = 0;
    memset(Heap.memspace, 0, (unsigned long int)size);
    Heap.allocs = malloc(Heap.capacity * SizeofAllocs);
    assert(Heap.allocs);
    Heap.initialized = true;
    srand(getpid());

    return;
}

export void nuninit() {
   munmap(Heap.memspace, (unsigned long int)Heap.size);
   Heap.size = 0;
   Heap.initialized = false;

   return;
}

export void *nalloc(char *identifier) {
    void *ret;
    int32 offset;
    int32 id;
    IdentResult res;

    if (Heap.capacity < Heap.allocations) {
        errno = 1;
        return (void *)0;
    }
    res = nverifyident(identifier);
    switch (res) {
        case IdentBadFormat:
            errno = 2;
            return (void *)0;
        case IdentTaken:
            errno = 1;
            return (void *)0;
        case IdentOk:
        default:
            break;
    }
    
    id = Heap.allocations;
    offset = (Heap.allocations * Blocksize);
    ret = (void *)Heap.memspace + offset;
    Heap.allocations++;

    Heap.allocs[id].id = id;
    unlock(id);
    strncpy((char *)Heap.allocs[id].identifier, identifier, 63);

    return ret;
}

#define nfree(x) ->"Deallocations not supported, instead: deallocate all by calling nuninit()."

void nmain(int16 _nid, int16 core, cb callback) {
    cpu_set_t set;
    nid = _nid;

    usecore(set, core);
    printf("[%d] Thread start on CPU core %d\n",
        (unsigned int )nid, (unsigned int)core);
    fflush(stdout);
    srand(getpid());

    (volatile void)callback(_nid);
    exit(0);

    return;

}

int16 countcores() {
    int16 ret;
    unsigned long int cores;

    cores = sysconf(_SC_NPROCESSORS_ONLN);
    ret = (int16)cores;

    return ret;
}

export void spawn_multiple(cb callback) {
    int16 cores, i;

    cores = countcores();
    for (i=1; i<=cores; i++)
        if (!fork())
            nmain(i, (i-1), callback);
    
    for (i=1; i<=cores; i++)
        if (wait(0) == -1)
            break;

    return;
}

export void spawn_single(int16 _nid, int16 core, cb callback) {
    int16 cores;

    cores = countcores();
    assert(core < cores);
    numneedles++;
    if (!fork())
        nmain(_nid, core, callback);

    return;
}

export void awaitneedles() {
    while (numneedles--)
        if (wait(0) == -1)
            break;

    return;
}